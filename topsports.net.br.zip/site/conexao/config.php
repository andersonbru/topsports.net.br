<?php
define('DB_HOSTNAME', 'mysql.hostinger.com.br');
define('DB_USERNAME', 'u448687765_site');
define('DB_PASSWORD', 'topsports2014');
define('DB_DATABASE', 'u448687765_site');

define('DB_PREFIX', 'tbl');
define('DB_CHARSET','utf8');
?>