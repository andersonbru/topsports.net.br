<div class="row">
	<div class="col-md-1 col-lg-1"></div>
	<div class="col-xs-12 col-sm-12 col-md-5 col-lg-5">
		<img src="img/<?=$EMPRESA['logo']?>" class="img img-responsive" />
	</div>
	<div class="col-xs-12 col-sm-12 col-md-5 col-lg-5">
		<div class="row">
			<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 text-right">
				<br />
				<p><span class="glyphicon glyphicon-earphone azul-topsports" aria-hidden="true"></span> <?=$EMPRESA['telefone']?></p>
				<p><span class="glyphicon glyphicon-envelope azul-topsports" aria-hidden="true"></span> <?=$EMPRESA['email']?></p>
				<p>
					<button class="btn btn-primary" type="button">
						<span class="glyphicon glyphicon-shopping-cart" aria-hidden="true"></span>
					  	Meus Pedidos <span class="badge">4</span>
					</button>
				</p>
			</div>
		</div>				
	</div>
	<div class="col-md-1 col-lg-1"></div>
</div>